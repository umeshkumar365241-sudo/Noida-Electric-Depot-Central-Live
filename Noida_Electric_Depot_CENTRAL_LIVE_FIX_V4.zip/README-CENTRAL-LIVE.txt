CENTRAL LIVE DATA SETUP

This build no longer requires Cloudflare D1 or a manually-created D1 database.
It uses one Cloudflare Durable Object with built-in SQLite storage as the central source of truth.

One-time deployment is still required on your Cloudflare account. After the project is deployed, the same URL uses the same central storage automatically; do not upload/import the ZIP again for every new data update.

Import behavior: merge/append, never clear existing report data. Exact fingerprints are upserted.
Login/users/passwords are stored centrally in the same persistent storage and can be recreated/changed from the app.

IMPORTANT: The first deployment creates a fresh central store. Existing local browser data must be imported once after deployment if you want it in the central store. After that, users/devices share the same live data.

If using Cloudflare Pages, deploy the project as a Pages Functions/Workers project with the included wrangler.toml. The Durable Object namespace is provisioned by the migration during deployment; no D1 database creation is required.
