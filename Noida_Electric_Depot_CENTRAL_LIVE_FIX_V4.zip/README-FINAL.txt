FINAL NOIDA ELECTRIC DEPOT REPORT

Driver mapping rule:
DETAILED DATA -> WAYBILL NUMBER -> TTM/Waybill Driver Name -> DRIVER MASTER Pay Roll ID.

Vehicle Number and Collection Date are NOT used to infer/guess a driver.
No extra Driver Code column is added; the Pay Roll ID appears in the same DRIVER NAME cell as:
DRIVER NAME - PAYROLL ID

All existing reports, MASTER, BUS DATA, DRIVER NAME and CONDUCTOR NAME remain included.


FINAL DISPLAY FIX: Detailed Data now has a pre-resolved Waybill -> Driver mapping for the embedded report rows, so Driver Name is rendered in the same DRIVER NAME column instead of remaining blank. Payroll ID is appended from MASTER DRIVER. No extra driver-code column is added.

FINAL AUTHENTICATION / LOGIN-TIMING FIX:
- LOGOUT is now available directly inside the logged-in ADMIN/USER dropdown.
- Login time is recorded from the server at successful login.
- Logout time is recorded by the server when LOGOUT is clicked.
- ADMIN -> LOGIN HISTORY opens the Management login history showing USER NAME, USERNAME, ROLE, LOGIN TIME, LOGOUT TIME and STATUS.
- Management also contains a REFRESH HISTORY button.
- Existing dashboard, reports, master data, driver mapping and report layout are preserved.

Hardware Inventory: ETIM Device Code prefixes mapped to depot: KSB=KAUSHAMBI, SBD=SAHIBABAD, GZD=GHAZIABAD, HPR=HAPUR, LNI=LONI, SKD=SIKANDRABAD, BSR=BULANDSHAHR, KRJ=KHURJA.


FINAL 5.1 UI/DEPLOYMENT FIXES:
- Dashboard page now contains ONLY three authority dashboards: NOIDA AUTHORITY, GREATER NOIDA AUTHORITY and YAMUNA AUTHORITY, each with a separate color.
- Ghaziabad/Noida Quality ETIM management tables are no longer rendered underneath the main Dashboard; they remain available through MANAGEMENT.
- Hardware inventory uses visible depot buttons instead of a popup-only dropdown. Ghaziabad has all 8 depots and 965 mapped ETIM rows from the supplied hardware source.
- Hardware supports ADMIN ADD, EDIT and DELETE with browser-local persistence, plus Excel export.
- Unused duplicate JS files were removed from the deployment package to reduce upload file count/size. Source XLSX files are retained.
- Noida hardware source rows were not fabricated; the package shows the three requested Noida depot names and reports when a depot has no source hardware rows.


LIVE DATA / CENTRAL SYNC UPDATE
- Import is MERGE/APPEND only; it never clears the existing browser data. Exact duplicate records are skipped.
- The app now includes central live-data sync endpoints in _worker.js using Cloudflare D1 table report_data.
- After deployment, configure the existing D1 binding named DB with a real database_id in wrangler.toml.
- Logged-in users with edit permission can push data; logged-in users can read the shared central dataset.
- The central server becomes the shared source of truth; local browser data is retained as a cache/fallback.
- Before production deployment, export/backup current data and import it once into the new central store.
