FINAL CENTRAL LIVE SYNC - DATA PRESERVATION BUILD

What is corrected:
1. Central server data and browser-local data are MERGED, never replaced on login/sync.
2. A browser containing newer local rows can publish those rows to the central Durable Object on its first authenticated sync.
3. A browser containing older local rows receives the central rows and keeps its own non-duplicate rows.
4. Import/save sends the full dataset to the server in batches of 200 rows, instead of only the last 200 rows.
5. After login, sync runs immediately.
6. While logged in, sync also runs on focus/visibility changes and every 30 seconds.
7. The central server remains the shared source for users/devices; localStorage is only a cache/fallback.
8. Existing users can still be recreated/reset through the existing user-management functions.
9. No Cloudflare D1 database is required. The Durable Object uses its built-in SQLite storage.

Validation performed before packaging:
- JavaScript syntax check passed for index.html embedded application script.
- Worker JavaScript syntax check passed.
- Merge logic was checked to preserve the union of local and central rows.
- Upload batching was checked to avoid the previous last-200-row truncation.

Deployment note:
The ZIP still needs to be deployed to the Cloudflare Worker/Pages environment once. The Durable Object binding in wrangler.toml is configured as DATA/CentralData. After deployment, the same URL should be used by all devices/browsers.

IMPORTANT:
A real cross-device live-sync test requires the ZIP to be deployed to the user's Cloudflare environment. It cannot be fully simulated from a local ZIP alone. Do not call this ZIP "live-tested" until the deployed URL is tested from two separate browser sessions.
