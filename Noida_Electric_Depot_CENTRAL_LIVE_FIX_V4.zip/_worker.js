const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','access-control-allow-origin':'*','access-control-allow-headers':'Content-Type,Authorization','access-control-allow-methods':'GET,POST,OPTIONS'}});
const norm=s=>String(s??'').trim().toLowerCase();
async function hash(text){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(String(text)));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');}
function token(){return crypto.randomUUID()+crypto.randomUUID();}

export class CentralData {
  constructor(state,env){this.state=state;this.env=env;this.sql=state.storage.sql;this.ready=this.init();}
  async init(){
    this.sql.exec(`CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY,name TEXT NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL,perm_view INTEGER NOT NULL DEFAULT 1,perm_edit INTEGER NOT NULL DEFAULT 0,perm_delete INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY,username TEXT NOT NULL,expires_at INTEGER NOT NULL)`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS login_history (id INTEGER PRIMARY KEY AUTOINCREMENT,token_hash TEXT NOT NULL,username TEXT NOT NULL,login_at TEXT NOT NULL,logout_at TEXT)`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS report_data (fingerprint TEXT PRIMARY KEY,payload TEXT NOT NULL,updated_at TEXT NOT NULL,updated_by TEXT NOT NULL)`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS etim_master (fingerprint TEXT PRIMARY KEY,payload TEXT NOT NULL,updated_at TEXT NOT NULL,updated_by TEXT NOT NULL)`);
    const row=this.sql.exec('SELECT username FROM users WHERE username=?','admin').toArray()[0];
    if(!row){const now=new Date().toISOString();const seed=[['admin','ADMIN','admin','ADMIN',1,1,1],['user','USER','user','VIEW + EDIT',1,1,0],['guest','GUEST','guest','VIEW ONLY',1,0,0]];for(const [u,n,p,r,v,e,d] of seed)this.sql.exec('INSERT INTO users(username,name,password_hash,role,perm_view,perm_edit,perm_delete,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)',u,n,await hash(p),r,v,e,d,now,now);}
  }
  async sessionUser(t){if(!t)return null;const th=await hash(t);const s=this.sql.exec('SELECT username,expires_at FROM sessions WHERE token_hash=?',th).toArray()[0];if(!s||Number(s.expires_at)<Date.now())return null;return this.sql.exec('SELECT username,name,role,perm_view,perm_edit,perm_delete FROM users WHERE username=?',s.username).toArray()[0]||null;}
  safeUser(r){return{username:r.username,name:r.name,role:r.role,permissions:{view:!!r.perm_view,edit:!!r.perm_edit,delete:!!r.perm_delete}};}
  async fetch(request){
    if(request.method==='OPTIONS')return json({ok:true});
    try{await this.ready}catch(e){return json({ok:false,error:'Central database initialization failed: '+String(e?.message||e)},500);}
    let body={};try{if(request.method!=='GET')body=await request.json();}catch{return json({ok:false,error:'Invalid JSON'},400)}
    const action=body.action||new URL(request.url).searchParams.get('action')||'health';
    try{
      if(action==='health')return json({ok:true,service:'central-live-sync',storage:'durable-object-sqlite'});
      if(action==='login'){
        const username=norm(body.username),password=String(body.password||'');
        const u=this.sql.exec('SELECT * FROM users WHERE username=?',username).toArray()[0];
        if(!u||(await hash(password))!==u.password_hash)return json({ok:false,error:'Invalid username or password.'},401);
        const t=token(),th=await hash(t),exp=Date.now()+1000*60*60*24*30,loginAt=new Date().toISOString();
        this.sql.exec('INSERT INTO sessions(token_hash,username,expires_at) VALUES(?,?,?)',th,u.username,exp);
        this.sql.exec('INSERT INTO login_history(token_hash,username,login_at,logout_at) VALUES(?,?,?,NULL)',th,u.username,loginAt);
        return json({ok:true,token:t,user:Object.assign(this.safeUser(u),{loginAt})});
      }
      const tokenValue=request.headers.get('Authorization')?.replace(/^Bearer\s+/i,'')||body.token;
      if(action==='logout'){if(tokenValue){const th=await hash(tokenValue);this.sql.exec('UPDATE login_history SET logout_at=? WHERE token_hash=? AND logout_at IS NULL',new Date().toISOString(),th);this.sql.exec('DELETE FROM sessions WHERE token_hash=?',th);}return json({ok:true});}
      const current=await this.sessionUser(tokenValue);
      if(action==='dataList'){
        if(!current)return json({ok:false,error:'Login required.'},401);
        const rows=this.sql.exec('SELECT payload FROM report_data ORDER BY updated_at ASC').toArray().map(x=>{try{return JSON.parse(x.payload)}catch{return null}}).filter(Boolean);
        return json({ok:true,rows});
      }
      if(action==='dataUpsert'){
        if(!current)return json({ok:false,error:'Login required.'},401);if(!current.perm_edit&&current.role!=='ADMIN')return json({ok:false,error:'Edit permission required.'},403);
        const incoming=Array.isArray(body.rows)?body.rows:[],fps=Array.isArray(body.fingerprints)?body.fingerprints:[];let saved=0;
        for(let i=0;i<incoming.length;i++){const fp=String(fps[i]||'').trim();if(!fp)continue;this.sql.exec('INSERT INTO report_data(fingerprint,payload,updated_at,updated_by) VALUES(?,?,?,?) ON CONFLICT(fingerprint) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at,updated_by=excluded.updated_by',fp,JSON.stringify(incoming[i]),new Date().toISOString(),current.username);saved++;}
        return json({ok:true,saved});
      }
      if(action==='dataDelete'){
        if(!current)return json({ok:false,error:'Login required.'},401);if(!current.perm_delete&&current.role!=='ADMIN')return json({ok:false,error:'Delete permission required.'},403);
        const fps=Array.isArray(body.fingerprints)?body.fingerprints.filter(Boolean):[];for(const fp of fps)this.sql.exec('DELETE FROM report_data WHERE fingerprint=?',String(fp));return json({ok:true,deleted:fps.length});
      }
      const admin=await this.sessionUser(tokenValue);if(!admin||admin.role!=='ADMIN')return json({ok:false,error:'Admin login required.'},403);
      if(action==='list'){const users=this.sql.exec('SELECT username,name,role,perm_view,perm_edit,perm_delete FROM users WHERE username<>? ORDER BY name,username','admin').toArray().map(this.safeUser);return json({ok:true,users});}
      if(action==='history'){const rows=this.sql.exec('SELECT h.id,h.username,u.name,u.role,h.login_at,h.logout_at FROM login_history h LEFT JOIN users u ON u.username=h.username ORDER BY h.id DESC LIMIT 500').toArray().map(x=>({id:x.id,username:x.username,name:x.name||x.username,role:x.role||'',loginAt:x.login_at,logoutAt:x.logout_at||''}));return json({ok:true,history:rows});}
      if(action==='deleteHistory'){const id=Number(body.id);if(!Number.isInteger(id)||id<1)return json({ok:false,error:'Valid history record is required.'},400);this.sql.exec('DELETE FROM login_history WHERE id=?',id);return json({ok:true});}
      if(action==='clearHistory'){this.sql.exec('DELETE FROM login_history');return json({ok:true});}
      if(action==='create'){const username=norm(body.username),name=String(body.name||'').trim(),password=String(body.password||''),role=String(body.role||'CUSTOM'),p=body.permissions||{};if(!username||!name||password.length<4)return json({ok:false,error:'Full name, username and password (min 4 characters) are required.'},400);if(!p.view&&!p.edit&&!p.delete)return json({ok:false,error:'Select at least one permission.'},400);if(this.sql.exec('SELECT username FROM users WHERE username=?',username).toArray()[0])return json({ok:false,error:'Username already exists.'},409);const now=new Date().toISOString();this.sql.exec('INSERT INTO users(username,name,password_hash,role,perm_view,perm_edit,perm_delete,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)',username,name,await hash(password),role,p.view?1:0,p.edit?1:0,p.delete?1:0,now,now);return json({ok:true});}
      if(action==='updatePermissions'){const username=norm(body.username),role=String(body.role||'CUSTOM'),p=body.permissions||{};if(username==='admin')return json({ok:false,error:'Admin account permissions cannot be changed here.'},400);this.sql.exec('UPDATE users SET role=?,perm_view=?,perm_edit=?,perm_delete=?,updated_at=? WHERE username=?',role,p.view?1:0,p.edit?1:0,p.delete?1:0,new Date().toISOString(),username);return json({ok:true});}
      if(action==='resetPassword'){const username=norm(body.username),password=String(body.password||'');if(password.length<4)return json({ok:false,error:'Password must be at least 4 characters.'},400);if(username==='admin')return json({ok:false,error:'Use Change Admin Password for admin.'},400);this.sql.exec('UPDATE users SET password_hash=?,updated_at=? WHERE username=?',await hash(password),new Date().toISOString(),username);return json({ok:true});}
      if(action==='changeAdminPassword'){const oldp=String(body.oldPassword||''),newp=String(body.newPassword||''),a=this.sql.exec('SELECT password_hash FROM users WHERE username=?','admin').toArray()[0];if(!a||(await hash(oldp))!==a.password_hash)return json({ok:false,error:'Current admin password is incorrect.'},400);if(newp.length<4)return json({ok:false,error:'New password must be at least 4 characters.'},400);this.sql.exec('UPDATE users SET password_hash=?,updated_at=? WHERE username=?',await hash(newp),new Date().toISOString(),'admin');return json({ok:true});}
      return json({ok:false,error:'Unknown action'},400);
    }catch(e){return json({ok:false,error:String(e?.message||e)},500)}
  }
}

export default {async fetch(request,env,ctx){const url=new URL(request.url);if(url.pathname!=='/api/users')return env.ASSETS?env.ASSETS.fetch(request):new Response('Not found',{status:404});if(!env.DATA||typeof env.DATA.idFromName!=='function')return json({ok:false,error:'Central Durable Object binding DATA is missing. Deploy the separate noida-electric-depot-central Worker and bind DATA to it in the Pages project.'},503);try{const id=env.DATA.idFromName('central-noida-electric-depot');const stub=env.DATA.get(id);return stub.fetch(request)}catch(e){return json({ok:false,error:'Central Durable Object request failed: '+String(e?.message||e)},500)}}};
