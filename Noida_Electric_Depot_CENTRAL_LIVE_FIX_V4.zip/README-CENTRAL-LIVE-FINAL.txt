CENTRAL LIVE SYNC V4 — FIXED ARCHITECTURE

The previous build could display "Central server request failed (500)" because it attempted to provision/use the Durable Object from inside the Pages project. Cloudflare Pages requires a Durable Object to be hosted by a separate Worker and then bound to the Pages project.

This build separates the architecture:
- ./central-worker/worker.js = central Durable Object Worker
- ./central-worker/wrangler.toml = SQLite Durable Object migration and binding
- ./_worker.js = Pages application worker
- ./wrangler.toml = Pages binding to the external central Worker

The application still uses the same /api/users endpoint and the same shared Durable Object name, so all browser/device sessions use the central database after deployment.

The login endpoint also now returns a useful JSON error if the central binding is missing or the central database initialization fails, instead of a generic browser 500.
